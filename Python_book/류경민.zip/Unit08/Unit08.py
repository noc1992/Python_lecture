# 심사문제 8
korean, english, mathematics, science = map(int, input().split(','))
print(bool(korean >= 90 and english > 80 and mathematics >85  and science >= 80))