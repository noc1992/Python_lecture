# 심사문제 10
a = int(input())
print(tuple(range(-10, 10, a)))