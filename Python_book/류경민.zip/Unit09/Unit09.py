# 심사문제 9
s = '''\'Python\' is a "programming language"
that lets you work quickly
and
integrate systems more effectively.'''
