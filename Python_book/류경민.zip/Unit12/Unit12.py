# 심사문제 12
a = input().split()
b = list(map(float, input().split()))
print(dict(zip(a[:], b[:])))