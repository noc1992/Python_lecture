#심사문제 11-8
x = input().split()
print(tuple(x[:len(x) - 5])

# 심사문제 11-9
a = input()
b = input()
c = a[1:len(a):2]
d = b[0:len(b):2]
print(c + d)